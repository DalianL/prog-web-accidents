import { Component, ViewChild, ElementRef } from '@angular/core';
import { NavController, App } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { Geolocation } from '@ionic-native/geolocation';

declare var google;

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  @ViewChild('map') mapElement: ElementRef;
  map: any;
  coordinates: any;
  countries: string[];
  errorMessage: string;

  constructor(public navCtrl: NavController, public rest: RestProvider, public geolocation: Geolocation, public app: App) {

  }

  ionViewDidLoad() {
    this.loadMap();
  }
  
  loadMap(){
 
    this.geolocation.getCurrentPosition().then((position) => {
 
      let latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
      this.getAccidents([position.coords.latitude, position.coords.longitude]);
 
      let mapOptions = {
        center: latLng,
        zoom: 15,
        mapTypeId: google.maps.MapTypeId.ROADMAP
      }
 
      this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
 
    }, (err) => {
      console.log(err);
    });
 
  }

  getAccidents(coords: any) {
    this.rest.getAccidents(coords)
       .subscribe(
         countries => this.countries = countries,
         error =>  this.errorMessage = <any>error);
  }

  logout() {
    //Api Token Logout 
    const root = this.app.getRootNav();
    root.popToRoot();
  }

}