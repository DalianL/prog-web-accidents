import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

/*
  Generated class for the RestProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class RestProvider {
  coordinates: any;

  // private apiUrl = 'https://restcountries.eu/rest/v2/all';
  private apiUrl = 'http://172.20.10.7:8000/getRouteByPosition?';

  constructor(public http: HttpClient) {
    console.log('Hello RestProvider Provider');
  }

  getAccidents(coords: any): Observable<string[]> {
    this.apiUrl += 'lat=' + coords[0] + '&lon=' + coords[1] + '&departement=6';
    console.log(this.apiUrl);
    return this.http.get(this.apiUrl)
                    .map(this.extractData)
                    .catch(this.handleError);
  }
  
  // private extractData(res: Response) {
  //   let body = res;
  //   return body || { };
  // }

  private extractData(res: Response) {
    console.log(res);
  }
  
  private handleError (error: Response | any) {
    let errMsg: string;
    if (error instanceof Response) {
      const err = error || '';
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Observable.throw(errMsg);
  }

}
